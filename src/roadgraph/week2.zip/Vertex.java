package roadgraph;

import java.util.List;
import java.util.LinkedList;
import geography.GeographicPoint;
import roadgraph.Edge;

public class Vertex {
	private List<Edge> edges;
	private GeographicPoint location;
	
	public Vertex(GeographicPoint location) {
		// TODO Auto-generated constructor stub
		this.location = location;
		this.edges = new LinkedList<Edge>();
	}
	
	public void addEdge(Edge street){
		edges.add(street);
	}
	
	public List<Edge> getEdges(){
		return edges;
	}
	
	public GeographicPoint getLocation(){
		return location;
	}

}

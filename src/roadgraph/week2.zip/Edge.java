package roadgraph;

import geography.GeographicPoint;

public class Edge {
	
	private GeographicPoint start;
	private GeographicPoint end;
	private String name;
	private String type;
	private double streetLength;
	
	public Edge(GeographicPoint start, GeographicPoint end, String name, String type, double length) {
		// TODO Auto-generated constructor stub
		this.start = start;
		this.end = end;
		this.name = name;
		this.type = type;
		this.streetLength = length;
	}
	
	public GeographicPoint getStart(){
		return start;
	}
	
	public GeographicPoint getEnd(){
		return end;
	}
	
	public String getName(){
		return name;
	}

}

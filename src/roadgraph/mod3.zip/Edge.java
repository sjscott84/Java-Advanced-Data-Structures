package roadgraph;

import geography.GeographicPoint;

public class Edge {
	
	private GeographicPoint start;
	private GeographicPoint end;
	private String name;
	private String type;
	private double streetLength;
	
	//Constructor to create the edge with the start, end, name, type and length
	public Edge(GeographicPoint start, GeographicPoint end, String name, String type, double length) {
		this.start = start;
		this.end = end;
		this.name = name;
		this.type = type;
		this.streetLength = length;
	}
	
	//This method returns the start location of the edge
	public GeographicPoint getStart(){
		return start;
	}
	
	//This method returns the end location of the edge
	public GeographicPoint getEnd(){
		return end;
	}
	
	/*As this project only required the locations of the edges I have not writted methods to return the name, type or length
	 * however, those methods would go here if needed*/
	
	public double getLength(){
		return streetLength;
	}
}
